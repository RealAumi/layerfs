## Node results

All measured cells are **single samples**. Bytes are exact. Times are seconds.

| Scenario | Mode | Time (s) | Uploaded B | Fetched B | Store growth B | Notes |
| --- | --- | --- | ---: | ---: | ---: | --- |
| S1 shared warm base | off builder | clone 3.954; install 58.422; builds 7.363 + 18.515; Commits 18.452 + 0.077 | 512,651,948 | 52,033,562 | 189,661,184 | Initial partial build/Node 22 cold test failed; full build revised on Node 20, reusing installed base. Final 71,585 files / 1,182,803,886 B. |
| S2 cold mount + test | off | 6.037 | 0 | 37,860,746 | 0 | No reinstall |
| S6 mount → tests finish | off | 5.887 FAIL | 0 | 37,997,907 | 0 | Failed test; not time to pass |
| S3 edit 01 | off | work 2.619; Commit 0.053 | 175,280 | 12,723,215 | 73,728 |  |
| S3 edit 02 | off | work 2.358; Commit 0.020 | 132,878 | 1,040 | 24,576 |  |
| S3 edit 03 | off | work 2.406; Commit 0.022 | 132,879 | 1,040 | 24,576 |  |
| S3 edit 04 | off | work 2.373; Commit 0.020 | 132,880 | 1,040 | 20,480 |  |
| S3 edit 05 | off | work 2.375; Commit 0.020 | 132,881 | 1,040 | 24,576 |  |
| S3 edit 06 | off | work 2.393; Commit 0.020 | 132,882 | 1,040 | 28,672 |  |
| S3 edit 07 | off | work 2.432; Commit 0.020 | 132,883 | 1,040 | 24,576 |  |
| S3 edit 08 | off | work 2.364; Commit 0.020 | 132,884 | 1,040 | 24,576 |  |
| S3 edit 09 | off | work 2.436; Commit 0.020 | 132,885 | 1,040 | 24,576 |  |
| S3 edit 10 | off | work 2.453; Commit 0.020 | 132,888 | 1,040 | 24,576 |  |
| S4 clean build | off | work 16.641; Commit 0.064 | 53,773 | 23,005,467 | 57,344 |  |
| S5 dependency change | off | work 17.170; Commit 0.068 | 664,099 | 1,393,249 | 323,584 |  |
| S2 cold mount + test | on | 5.718 | 0 | 37,937,372 | 0 | No reinstall |
| S6 mount → tests finish | on | 25.880 FAIL | 0 | 74,061,358 | 0 | Failed test; not time to pass |
| S3 edit 01 | on | work 2.752; Commit 0.056 | 30,041 | 13,007,798 | 32,768 |  |
| S3 edit 02 | on | work 2.304; Commit 0.017 | 12,838 | 887 | 8,192 |  |
| S3 edit 03 | on | work 2.366; Commit 0.014 | 12,839 | 887 | 8,192 |  |
| S3 edit 04 | on | work 2.289; Commit 0.015 | 12,840 | 887 | 8,192 |  |
| S3 edit 05 | on | work 2.456; Commit 0.015 | 12,841 | 887 | 8,192 |  |
| S3 edit 06 | on | work 2.540; Commit 0.016 | 12,842 | 887 | 12,288 |  |
| S3 edit 07 | on | work 2.507; Commit 0.015 | 12,843 | 887 | 8,192 |  |
| S3 edit 08 | on | work 2.546; Commit 0.016 | 12,844 | 887 | 8,192 |  |
| S3 edit 09 | on | work 2.562; Commit 0.015 | 12,845 | 887 | 8,192 |  |
| S3 edit 10 | on | work 2.515; Commit 0.017 | 12,847 | 887 | 8,192 |  |
| S4 clean build | on | work 17.910; Commit 0.039 | 0 | 23,160,736 | 0 |  |
| S5 dependency change | on | work 16.988; Commit 0.069 | 210,600 | 1,295,415 | 106,496 |  |
| S7 rebuild left | off | work 19.445; Commit 0.093 | 174,140 | 51,828,215 | 69,632 |  |
| S7 rebuild right | off | work 17.741; Commit 0.077 | 186,043 | 18,575 | 61,440 |  |
| S7 generated merge | off | SDK 0.013 | — | — | 4,096 | 3 LWW decisions; no conflicts. Growth interval includes preceding unmount; SDK is Store-local. |
| S7 source-control left | off | work 0.048; Commit 0.014 | 15,311 | 818 | 16,384 |  |
| S7 source-control right | off | work 0.042; Commit 0.011 | 15,312 | 819 | 8,192 |  |
| S7 source conflict | off | SDK 0.003 | — | — | — | Expected Conflict; no merge Commit |

## Maven results

All measured cells are **single samples**. Bytes are exact. Times are seconds.

| Scenario | Mode | Time (s) | Uploaded B | Fetched B | Store growth B | Notes |
| --- | --- | --- | ---: | ---: | ---: | --- |
| S1 / S8a shared warm base | off builder | clone 1.421; install 414.735; build/test 11.728; Commit 0.911 | 69,412,328 | 14,171 | 64,937,984 | 360 repo files / 70,465,522 B; .m2 on separate shared volume. |
| S2 cold mount + test | off | 3.582 | 0 | 1,634,337 | 0 | No reinstall |
| S6 mount → tests finish | off | 3.311 | 0 | 1,648,509 | 0 | No reinstall |
| S3 edit 01 | off | work 3.765; Commit 0.500 | 563,887 | 1,207,273 | 163,840 |  |
| S3 edit 02 | off | work 3.559; Commit 0.457 | 150,938 | 7,238 | 126,976 |  |
| S3 edit 03 | off | work 4.301; Commit 0.553 | 159,970 | 6,495 | 131,072 |  |
| S3 edit 04 | off | work 4.131; Commit 0.452 | 145,731 | 6,495 | 114,688 |  |
| S3 edit 05 | off | work 4.126; Commit 0.415 | 151,048 | 6,499 | 126,976 |  |
| S3 edit 06 | off | work 3.983; Commit 0.442 | 151,182 | 6,499 | 126,976 |  |
| S3 edit 07 | off | work 3.713; Commit 0.442 | 151,316 | 6,499 | 126,976 |  |
| S3 edit 08 | off | work 3.784; Commit 0.447 | 164,941 | 6,498 | 131,072 |  |
| S3 edit 09 | off | work 3.808; Commit 0.411 | 146,051 | 6,495 | 118,784 |  |
| S3 edit 10 | off | work 3.721; Commit 0.467 | 150,843 | 6,498 | 122,880 |  |
| S4 clean build | off | work 3.740; Commit 0.605 | 354,698 | 151,762 | 303,104 |  |
| S5 dependency change | off | work 7.887; Commit 0.578 | 1,195,342 | 6,520 | 1,069,056 |  |
| S2 cold mount + test | on | 5.114 | 0 | 1,634,535 | 0 | No reinstall |
| S6 mount → tests finish | on | 9.118 | 0 | 1,827,495 | 0 | Recovery includes reinstall/rebuild |
| S3 edit 01 | on | work 4.511; Commit 0.481 | 16,898 | 1,201,904 | 24,576 |  |
| S3 edit 02 | on | work 4.349; Commit 0.342 | 5,838 | 886 | 4,096 |  |
| S3 edit 03 | on | work 4.326; Commit 0.450 | 5,838 | 886 | 8,192 |  |
| S3 edit 04 | on | work 4.304; Commit 0.322 | 5,838 | 886 | 8,192 |  |
| S3 edit 05 | on | work 4.063; Commit 0.331 | 16,906 | 890 | 16,384 |  |
| S3 edit 06 | on | work 3.935; Commit 0.315 | 5,838 | 886 | 8,192 |  |
| S3 edit 07 | on | work 4.112; Commit 0.303 | 5,838 | 886 | 4,096 |  |
| S3 edit 08 | on | work 3.887; Commit 0.321 | 17,040 | 890 | 16,384 |  |
| S3 edit 09 | on | work 4.059; Commit 0.376 | 17,150 | 889 | 16,384 |  |
| S3 edit 10 | on | work 4.156; Commit 0.349 | 17,285 | 963 | 20,480 |  |
| S4 clean build | on | work 4.637; Commit 0.312 | 12,113 | 146,038 | 12,288 |  |
| S5 dependency change | on | work 7.774; Commit 0.307 | 20,749 | 886 | 8,192 |  |
| S7 rebuild left | off | work 3.236; Commit 0.620 | 165,820 | 2,203,651 | 135,168 |  |
| S7 rebuild right | off | work 3.902; Commit 0.446 | 139,429 | 188,288 | 86,016 |  |
| S7 generated merge | off | SDK 0.004 | — | — | 4,096 | 4 LWW decisions; no conflicts. Growth interval includes preceding unmount; SDK is Store-local. |
| S7 source-control left | off | work 0.038; Commit 0.005 | 5,743 | 817 | 20,480 |  |
| S7 source-control right | off | work 0.037; Commit 0.005 | 5,744 | 818 | 4,096 |  |
| S7 source conflict | off | SDK 0.002 | — | — | — | Expected Conflict; no merge Commit |
| S8b repo-local .m2 | off | install 422.889; build 8.848 FAIL | 0 | — | — | 3,757 NoHTTP violations in downloaded POMs; no warm-base Commit or cold sample |
| S8c base, two Workspaces | off | install 422.994; build/test 12.931; cache Commit 3.855; repo Commit 0.721 | 235,354,623 | 155,194 | 213,155,840 | One daemon; 3,823 cache files / 226,857,786 B. |
| S8c cold repo + cache forks | off | 6.662 | 0 | 56,602,286 | 0 | No reinstall |
| S8c thread fork | off | 0.077 | 0 | — | 0 | Independent writable Branch; metadata-only fork |
| S8c cache-thread fork | off | 0.047 | 0 | — | 0 | Independent writable Branch; metadata-only fork |
| S8c S5 complete change | off | work 9.566; Commits 0.717 | 1,608,478 | 87,406,511 | 1,081,344 | Total row; following rows split the two explicit Commits |
| S8c S5 cache Commit | off | 0.026 | 657,958 | 866 | 614,400 | ZXing core 3.5.3; cache fork never merged back |
| S8c S5 repo Commit | off | 0.691 | 950,520 | 979,797 | 466,944 | ZXing core 3.5.3; cache fork never merged back |

